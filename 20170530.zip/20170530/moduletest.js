/**
 * Created by kimilsik on 5/30/17.
 */
var o = require('os');
console.log(o.platform());ls
