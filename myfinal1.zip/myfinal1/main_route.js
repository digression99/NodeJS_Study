/**
 * Created by kimilsik on 7/14/17.
 */

module.exports = function (app) {
    var router = require('express').Router();

    router.get('/', function(req, res) {






    });
};

